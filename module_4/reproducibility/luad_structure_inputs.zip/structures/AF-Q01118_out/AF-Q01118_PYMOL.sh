#!/bin/bash
pymol AF-Q01118.pml
