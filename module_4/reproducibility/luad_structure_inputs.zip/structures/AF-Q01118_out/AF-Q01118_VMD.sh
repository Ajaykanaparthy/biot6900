#!/bin/bash
vmd AF-Q01118_out.pdb -e AF-Q01118.tcl
