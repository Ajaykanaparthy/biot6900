#!/bin/bash
pymol AF-P48740.pml
