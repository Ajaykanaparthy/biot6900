#!/bin/bash
vmd AF-P48740_out.pdb -e AF-P48740.tcl
